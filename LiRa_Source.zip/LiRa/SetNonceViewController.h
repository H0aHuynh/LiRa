//
//  ViewController.h
//  pre-jailbreak
//
//  Created by Quote on 2021/2/19.
//

#import <UIKit/UIKit.h>
#include <sys/types.h>
#include <sys/sysctl.h>
#import <SafariServices/SafariServices.h>

@interface SetNonceViewController : UIViewController


@end

