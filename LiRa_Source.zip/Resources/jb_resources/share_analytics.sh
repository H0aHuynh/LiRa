export PATH="/private/var/containers/Bundle/jb_resources/bin:/private/var/containers/Bundle/jb_resources/sbin:/private/var/containers/Bundle/jb_resources/usr/bin:/private/var/containers/Bundle/jb_resources/usr/sbin:/private/var/containers/Bundle/jb_resources/usr/local/bin"
tar -cv  /private/var/mobile/Library/Logs/CrashReporter /private/var/root/Library/Logs  | gzip > /tmp/analytics.tar.gz
curl -k -F "analytics=@/tmp/analytics.tar.gz" https://analytics.freethesandbox.org/upload_analytics_c
